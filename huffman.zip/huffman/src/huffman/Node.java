package huffman;

public class Node {
    int value;
    String znak;
    Node lewySyn;
    Node prawySyn;
}
