package Haszowanie;

import java.io.IOException;

public class Main {
    public static void main(String args[]) throws IOException {
//        System.out.println("KORZYSTNE");
//        System.out.format("    m   | stala | Najwieksza wartosc | Ilosc miejsc zerowych | Srednia wartosc\n");
//        Haszowanie.Zadanie_6_2.LiczenieKolizji(111, 1103);
//        Haszowanie.Zadanie_6_2.LiczenieKolizji(111, 1259);
//        Haszowanie.Zadanie_6_2.LiczenieKolizji(111, 1321);
//        Haszowanie.Zadanie_6_2.LiczenieKolizji(139, 1439);
//        Haszowanie.Zadanie_6_2.LiczenieKolizji(167, 1439);
//        Haszowanie.Zadanie_6_2.LiczenieKolizji(197, 1439);
//
//        System.out.println("\nNIEKORZYSTNE");
//        System.out.format("    m   | stala | Najwieksza wartosc | Ilosc miejsc zerowych | Srednia wartosc\n");
//        Haszowanie.Zadanie_6_2.LiczenieKolizji(111, 1102);
//        Haszowanie.Zadanie_6_2.LiczenieKolizji(111, 1258);
//        Haszowanie.Zadanie_6_2.LiczenieKolizji(111, 1320);
//        Haszowanie.Zadanie_6_2.LiczenieKolizji(139, 1438);
//        Haszowanie.Zadanie_6_2.LiczenieKolizji(167, 1438);
//        Haszowanie.Zadanie_6_2.LiczenieKolizji(197, 1438);
//
        Haszowanie.Zadanie_6_3.Start(111,10,0);

//        System.out.println("\nWIELKOSC M = 1000");
//        Haszowanie.Zadanie_6_3.Start(111,1000,50);
//        Haszowanie.Zadanie_6_3.Start(111,1000,70);
//        Haszowanie.Zadanie_6_3.Start(111,1000,90);
//        System.out.println("\nWIELKOSC M = 1009");
//        Haszowanie.Zadanie_6_3.Start(111,1009,50);
//        Haszowanie.Zadanie_6_3.Start(111,1009,70);
//        Haszowanie.Zadanie_6_3.Start(111,1009,90);
//        System.out.println("\nWIELKOSC M = 7000");
//        Haszowanie.Zadanie_6_3.Start(111,7000,50);
//        Haszowanie.Zadanie_6_3.Start(111,7000,70);
//        Haszowanie.Zadanie_6_3.Start(111,7000,90);
//        System.out.println("\nWIELKOSC M = 7001");
//        Haszowanie.Zadanie_6_3.Start(111,7001,50);
//        Haszowanie.Zadanie_6_3.Start(111,7001,70);
//        Haszowanie.Zadanie_6_3.Start(111,7001,90);
//        System.out.println("\nWIELKOSC M = 10000");
//        Haszowanie.Zadanie_6_3.Start(111,10000,50);
//        Haszowanie.Zadanie_6_3.Start(111,10000,70);
//        Haszowanie.Zadanie_6_3.Start(111,10000,90);
//        System.out.println("\nWIELKOSC M = 10007");
//        Haszowanie.Zadanie_6_3.Start(111,10007,50);
//        Haszowanie.Zadanie_6_3.Start(111,10007,70);
//        Haszowanie.Zadanie_6_3.Start(111,10007,90);
    }
}
